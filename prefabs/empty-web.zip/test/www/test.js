;(function(window) {
"use strict";
var require, resource, module;
var application;
var assert;
var Exception, AssertionFailedException;
(function() {
    var resources = { };
    var modules = { };
    Exception = function Exception(message) {
        this.message = message === undefined ? this.message : message;
        this.name = this.constructor.name === undefined ? 'Exception' : this.constructor.name;
        var current = this;
        var ownTraceSize = 1;
        while ((current = Object.getPrototypeOf(current)) instanceof Error) {
            ownTraceSize++;
        }
        var stack = Error().stack.split('\n').slice(ownTraceSize);
        stack[0] = this.name + ': ' + message;
        this.stack = stack.join('\n');
    };
    Exception.prototype = Object.create(Error.prototype);
    Exception.prototype.constructor = Exception;
    var getResource = function(name) {
        if (resources[name] === undefined) {
            throw Error('missing resource ' + name);
        }
        return resources[name];
    };
    var Module = function(name, func) {
        this.name = name;
        this.exports = Object.create(null);
        this.func = func;
    };
    Module.prototype.exports = null;
    Module.prototype.name = '';
    module = function(name, func) {
        modules[name] = new Module(name, func);
    };
    resource = function(name, data) {
        resources[name] = data;
    };
    application = function(Constructor) {
        function Application() {
            application = this;
            Constructor.apply(this, Array.prototype.slice.call(arguments));
        };
        Application.prototype = Constructor.prototype;
        var args = Array.prototype.slice.call(arguments);
        args[0] = null;
        return new (Function.prototype.bind.apply(Application, args));
    };
    require = function(file) {
        var module = modules[file];
        if (module === undefined) {
            throw Error('missing dependency ' + file);
        }
        if (typeof module.func === 'function') {
            var func = module.func;
            delete module.func;
            func(module, getResource);
        }
        return module.exports;
    };
    AssertionFailedException = function AssertionFailedException(message) {
        Exception.call(this, message);
    };
    AssertionFailedException.prototype = Object.create(Exception.prototype);
    AssertionFailedException.prototype.constructor = AssertionFailedException;
    assert = function(assertion, message) {
        if (assertion !== true) {
            throw new AssertionFailedException(message);
        }
    };
    assert.instance = function(type, allowNull, value, name, typeName) {
        if (value === null) {
            if (allowNull) {
                return;
            } else {
                throw new AssertionFailedException(name + ' expected to be instance of ' + typeName + ', got null instead');
            }
        }
        if (value instanceof type !== true) {
            var actualName = (typeof value === 'object' && typeof value.constructor === 'function' && typeof value.constructor.name === 'string' ? value.constructor.name : 'type ' + typeof value);
            throw new AssertionFailedException(name + ' expected to be instance of ' + typeName + ', got ' + actualName + ' instead');
        }
    }
    assert.type = function(type, allowNull, value, name) {
        type = (type !== 'func' ? type : 'function');
        if (value === null) {
            if (allowNull) {
                return;
            } else {
                throw new AssertionFailedException(name + ' expected to be of type ' + type + ', got null instead');
            }
        }
        var actualType = typeof value;
        if (type === 'finite' || type === 'number') {
            if (actualType !== 'number') {
                throw new AssertionFailedException(name + ' expected to be of type number, got ' + actualType + ' instead');
            }
            if (type === 'finite' && isFinite(value) === false) {
                throw new AssertionFailedException(name + ' expected to be finite number, got ' + value + ' instead');
            }
        } else if (type === 'scalar') {
            if (actualType === 'number' && isFinite(value) === false) {
                throw new AssertionFailedException(name + ' expected to be scalar, got ' + value + ' instead');
            } else if (actualType !== 'string' && actualType !== 'boolean') {
                throw new AssertionFailedException(name + ' expected to be scalar, got ' + actualType + ' instead');
            }
        } else if (type !== actualType) {
            throw new AssertionFailedException(name + ' expected to be of type ' + type + ', got ' + actualType + ' instead');
        }
    };
})();
module('../../astdlib/astd/prototype/merge.adria', function(module, resource) {
    var merge;
    merge = function merge(from, to) {
        var props;
        props = Object.getOwnPropertyNames(from);
        var propId, propName;
        for (propId in props) {
            propName = props[propId];
            if (to.hasOwnProperty(propName) === false && propName !== 'extend') {
                Object.defineProperty(to, propName, Object.getOwnPropertyDescriptor(from, propName));
            }
        }
    };
    module.exports = merge;
});
module('../../astdlib/astd/prototype/array.adria', function(module, resource) {
    var merge, extend, ArrayExtensions;
    merge = require('../../astdlib/astd/prototype/merge.adria');
    extend = function extend() {
        merge(ArrayExtensions, Array);
        merge(ArrayExtensions.prototype, Array.prototype);
    };
    ArrayExtensions = (function() {
        function ArrayExtensions() {}
        Object.defineProperty(ArrayExtensions.prototype, "first", {
            get: function first() {
                var i;
                for (i in this) {
                    return parseInt(i);
                }
                return null;
            }
        });
        Object.defineProperty(ArrayExtensions.prototype, "insert", {
            value: function insert(value) {
                return this.push(value) - 1;
            }
        });
        Object.defineProperty(ArrayExtensions.prototype, "remove", {
            value: function remove(id) {
                assert(typeof id === 'number', 'typeof id === \'number\'');
                assert(id < this.length, 'id < this.length');
                this[id] = this[this.length - 1];
                return --this.length;
            }
        });
        Object.defineProperty(ArrayExtensions.prototype, "random", {
            value: function random() {
                return this[Math.floor(Math.random() * this.length)];
            }
        });
        Object.defineProperty(ArrayExtensions.prototype, "unique", {
            value: function unique(arr) {
                var hash, result;
                hash = Object.create(null);
                result = [  ];
                var i, l, value;
                for (i = 0, l = this.length; i < l;++i) {
                    value = this[i];
                    if (value in hash === false) {
                        hash[value] = true;
                        result.push(value);
                    }
                }
                return result;
            }
        });
        return ArrayExtensions;
    })();
    module.exports = ArrayExtensions;
    module.exports.extend = extend;
});
module('../../astdlib/astd/prototype/date.adria', function(module, resource) {
    var merge, extend, dateLocale, zeroPad, dateMarkers, DateExtensions;
    merge = require('../../astdlib/astd/prototype/merge.adria');
    extend = function extend() {
        merge(DateExtensions, Date);
        merge(DateExtensions.prototype, Date.prototype);
    };
    dateLocale = {
        enGB: {
            months: [
                'Jan',
                'Feb',
                'Mar',
                'Apr',
                'May',
                'Jun',
                'Jul',
                'Aug',
                'Sep',
                'Oct',
                'Nov',
                'Dec'
            ],
            days: [ 'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat' ],
            monthsLong: [
                'January',
                'February',
                'March',
                'April',
                'May',
                'June',
                'July',
                'August',
                'September',
                'October',
                'November',
                'December'
            ],
            daysLong: [
                'Sunday',
                'Monday',
                'Tuesday',
                'Wednesday',
                'Thursday',
                'Friday',
                'Saturday'
            ]
        },
        deDE: {
            months: [
                'Jan',
                'Feb',
                'Mrz',
                'Apr',
                'Mai',
                'Jun',
                'Jul',
                'Aug',
                'Sep',
                'Okt',
                'Nov',
                'Dez'
            ],
            days: [ 'So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa' ],
            monthsLong: [
                'Januar',
                'Februar',
                'März',
                'April',
                'Mai',
                'Juni',
                'Juli',
                'August',
                'September',
                'Oktober',
                'November',
                'Dezember'
            ],
            daysLong: [
                'Sonntag',
                'Montag',
                'Dienstag',
                'Mittwoch',
                'Donnerstag',
                'Freitag',
                'Samstag'
            ]
        }
    };
    zeroPad = function zeroPad(number) {
        return ('0' + number).substr(-2, 2);
    };
    dateMarkers = {
        d: [
            'getDate',
            function(v) {
                return zeroPad(v);
            }
        ],
        m: [
            'getMonth',
            function(v) {
                return zeroPad(v + 1);
            }
        ],
        n: [
            'getMonth',
            function(v, locale) {
                return locale.months[v];
            }
        ],
        w: [
            'getDay',
            function(v, locale) {
                return locale.days[v];
            }
        ],
        y: [ 'getFullYear' ],
        H: [
            'getHours',
            function(v) {
                return zeroPad(v);
            }
        ],
        M: [
            'getMinutes',
            function(v) {
                return zeroPad(v);
            }
        ],
        S: [
            'getSeconds',
            function(v) {
                return zeroPad(v);
            }
        ],
        i: [ 'toISOString' ]
    };
    DateExtensions = (function() {
        function DateExtensions() {}
        DateExtensions.prototype.format = function format(formatString, localeName) {
            var ___al = arguments.length;
            var _this, locale;
            var ___localeName$i = (___al > 1 ? localeName : ('enGB'));
            _this = this;
            locale = dateLocale[___localeName$i];
            return formatString.replace(/%(.)/g, function(m, p) {
                var part;
                part = _this[dateMarkers[p][0]]();
                if (typeof dateMarkers[p][1] === 'function') {
                    part = dateMarkers[p][1](part, locale);
                }
                return part;
            });
        };
        return DateExtensions;
    })();
    module.exports = DateExtensions;
    module.exports.extend = extend;
});
module('../../astdlib/astd/prototype/function.adria', function(module, resource) {
    var merge, extend, FunctionExtensions;
    merge = require('../../astdlib/astd/prototype/merge.adria');
    extend = function extend() {
        merge(FunctionExtensions, Function);
        merge(FunctionExtensions.prototype, Function.prototype);
    };
    FunctionExtensions = (function() {
        function FunctionExtensions() {}
        FunctionExtensions.prototype.construct = function construct(argsArray) {
            var args;
            args = [ null ];
            Array.prototype.push.apply(args, argsArray);
            return new (Function.prototype.bind.apply(this, args));
        };
        FunctionExtensions.prototype.mixin = function mixin(constructor) {
            var thisProto, otherProto, props, propName;
            thisProto = this.prototype;
            otherProto = constructor.prototype;
            props = Object.getOwnPropertyNames(otherProto);
            var id;
            for (id in props) {
                propName = props[id];
                if (thisProto.hasOwnProperty(propName) === false) {
                    Object.defineProperty(thisProto, propName, Object.getOwnPropertyDescriptor(otherProto, propName));
                }
            }
        };
        return FunctionExtensions;
    })();
    module.exports = FunctionExtensions;
    module.exports.extend = extend;
});
module('../../astdlib/astd/prototype/math.adria', function(module, resource) {
    var merge, extend, MathExtensions, pick, tailDist, headDist, rand, randInt, sgn;
    merge = require('../../astdlib/astd/prototype/merge.adria');
    extend = function extend() {
        merge(MathExtensions, Math);
    };
    MathExtensions = {  };
    pick = function pick(itemTable) {
        var chance, total;
        chance = Math.random();
        total = 0;
        var id;
        for (id in itemTable) {
            total += itemTable[id];
            if (chance >= (total - itemTable[id]) && chance <= total) {
                return id;
            }
        }
        return null;
    };
    tailDist = function tailDist(range) {
        return Math.floor(Math.sqrt(Math.random() * range * range));
    };
    headDist = function headDist(range) {
        return range - 1 - Math.floor(Math.sqrt(Math.random() * range * range));
    };
    rand = function rand(min, max) {
        return Math.random() * (max - min) + min;
    };
    randInt = function randInt(min, max) {
        return Math.round(Math.random() * (max - min) + min);
    };
    sgn = function sgn(value) {
        return (value > 0) - (value < 0);
    };
    module.exports = MathExtensions;
    module.exports.extend = extend;
    module.exports.pick = pick;
    module.exports.tailDist = tailDist;
    module.exports.headDist = headDist;
    module.exports.rand = rand;
    module.exports.randInt = randInt;
    module.exports.sgn = sgn;
});
module('../../astdlib/astd/prototype/number.adria', function(module, resource) {
    var merge, extend, NumberExtensions;
    merge = require('../../astdlib/astd/prototype/merge.adria');
    extend = function extend() {
        merge(NumberExtensions, Number);
        merge(NumberExtensions.prototype, Number.prototype);
    };
    NumberExtensions = (function() {
        function NumberExtensions() {}
        Object.defineProperty(NumberExtensions.prototype, "sgn", {
            get: function sgn() {
                return (this > 0) - (this < 0);
            }
        });
        Object.defineProperty(NumberExtensions.prototype, "even", {
            get: function even() {
                return this % 2 === 0;
            }
        });
        Object.defineProperty(NumberExtensions.prototype, "odd", {
            get: function odd() {
                return this % 2 === 1;
            }
        });
        return NumberExtensions;
    })();
    module.exports = NumberExtensions;
    module.exports.extend = extend;
});
module('../../astdlib/astd/prototype/object.adria', function(module, resource) {
    var merge, extend, ObjectExtensions;
    merge = require('../../astdlib/astd/prototype/merge.adria');
    extend = function extend() {
        merge(ObjectExtensions, Object);
        merge(ObjectExtensions.prototype, Object.prototype);
    };
    ObjectExtensions = (function() {
        function ObjectExtensions() {}
        Object.defineProperty(ObjectExtensions.prototype, "merge", {
            value: function merge(overwrite) {
                assert.type('boolean', false, overwrite, 'argument 1 (overwrite)');
                var args, ___num$10 = arguments.length - 1;
                if (___num$10 > 0) {
                    args = new Array(___num$10);
                    for (var ___i$10 = 0; ___i$10 < ___num$10; ++___i$10) {
                        args[___i$10] = arguments[___i$10 + 1];
                    }
                } else {
                    args = [];
                }
                var i, len, argValue, props;
                for (i = 0, len = args.length; i < len;++i) {
                    argValue = args[i];
                    props = Object.getOwnPropertyNames(argValue);
                    if (overwrite === false) {
                        var propId, propName;
                        for (propId in props) {
                            propName = props[propId];
                            if (this.hasOwnProperty(propName) === false) {
                                Object.defineProperty(this, propName, Object.getOwnPropertyDescriptor(argValue, propName));
                            }
                        }
                    } else {
                        var propId, propName;
                        for (propId in props) {
                            propName = props[propId];
                            Object.defineProperty(this, propName, Object.getOwnPropertyDescriptor(argValue, propName));
                        }
                    }
                }
            },
            writable: true
        });
        Object.defineProperty(ObjectExtensions.prototype, "clone", {
            value: function clone() {
                return Object.create(Object.getPrototypeOf(this));
            },
            writable: true
        });
        return ObjectExtensions;
    })();
    module.exports = ObjectExtensions;
    module.exports.extend = extend;
});
module('../../astdlib/astd/prototype/regexp.adria', function(module, resource) {
    var merge, extend, RegExpExtensions, escape;
    merge = require('../../astdlib/astd/prototype/merge.adria');
    extend = function extend() {
        merge(RegExpExtensions, RegExp);
        merge(RegExpExtensions.prototype, RegExp.prototype);
    };
    RegExpExtensions = (function() {
        function RegExpExtensions() {}
        return RegExpExtensions;
    })();
    escape = function escape(string) {
        return string.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&');
    };
    module.exports = RegExpExtensions;
    module.exports.extend = extend;
    module.exports.escape = escape;
});
module('../../astdlib/astd/prototype/string.adria', function(module, resource) {
    var merge, extend, StringExtensions, random, repeat;
    merge = require('../../astdlib/astd/prototype/merge.adria');
    extend = function extend() {
        merge(StringExtensions, String);
        merge(StringExtensions.prototype, String.prototype);
    };
    StringExtensions = (function() {
        function StringExtensions() {}
        StringExtensions.prototype.snakeToCamel = (function() {
            var firstToUpper;
            firstToUpper = function firstToUpper(match1) {
                return match1.replace('_', '').toUpperCase();
            };
            return function snakeToCamel(upperFirst) {
                if (upperFirst) {
                    return this.replace(/((?:^|\_)[a-z])/g, firstToUpper);
                } else {
                    return this.replace(/(\_[a-z])/g, firstToUpper);
                }
            };
        })();
        StringExtensions.prototype.hasPrefix = function hasPrefix(prefix) {
            return (this.substr(0, prefix.length) === prefix);
        };
        StringExtensions.prototype.stripPrefix = function stripPrefix(prefix) {
            var len;
            if (prefix instanceof Array) {
                var i;
                for (i in prefix) {
                    len = prefix[i].length;
                    if (this.substr(0, len) === prefix[i]) {
                        return this.substr(len);
                    }
                }
                return this.valueOf();
            }
            len = prefix.length;
            return (this.substr(0, len) === prefix ? this.substr(len) : this.valueOf());
        };
        StringExtensions.prototype.addPrefix = function addPrefix(prefix) {
            return this.hasPrefix(prefix) ? this.valueOf() : prefix + this.valueOf();
        };
        StringExtensions.prototype.hasPostfix = function hasPostfix(postfix) {
            return (this.substr(-postfix.length) === postfix);
        };
        StringExtensions.prototype.stripPostfix = function stripPostfix(postfix) {
            var len;
            if (postfix instanceof Array) {
                var i;
                for (i in postfix) {
                    len = postfix[i].length;
                    if (this.substr(-len) === postfix[i]) {
                        return this.substr(0, this.length - len);
                    }
                }
                return this.valueOf();
            }
            len = postfix.length;
            return (this.substr(-len) === postfix ? this.substr(0, this.length - len) : this.valueOf());
        };
        StringExtensions.prototype.addPostfix = function addPostfix(postfix) {
            return this.hasPostfix(postfix) ? this.valueOf() : this.valueOf() + postfix;
        };
        StringExtensions.prototype.format = function format() {
            var ___num$1f = arguments.length, args = new Array(___num$1f);
            for (var ___i$1f = 0; ___i$1f < ___num$1f; ++___i$1f) {
                args[___i$1f] = arguments[___i$1f];
            }
            if (args.length === 1 && args[0] instanceof Object) {
                args = args[0];
            }
            return this.replace(/(.?)\$([0-9a-z]+)(\:([0-9a-z\:\-]+))?(\.?)/ig, function(str, prefix, matchname, optmatch, options, separator) {
                var formatted;
                if (prefix === '$') {
                    return '$' + matchname + (optmatch !== undefined ? optmatch : '') + (separator !== undefined ? separator : '');
                }
                formatted = args[matchname];
                if (options !== undefined) {
                    if (options.slice(-1) === '.') {
                        options = options.slice(0, -1);
                    }
                    if (options === 'currency') {
                        formatted = Math.floor(formatted * 100) / 100;
                    }
                    if (options.substr(0, 4) === 'pad:') {
                        formatted = String.prototype.padLeft.call('' + formatted, options.substr(4), ' ');
                    }
                }
                return (args[matchname] !== undefined ? prefix + formatted : str);
            });
        };
        StringExtensions.prototype.repeat = function repeat(count) {
            var result, pattern;
            if (count < 1) {
                return '';
            }
            result = '';
            pattern = this.valueOf();
            while (count > 1) {
                if (count & 1) {
                    result += pattern;
                }
                count >>= 1;
                pattern += pattern;
            }
            result += pattern;
            return result;
        };
        StringExtensions.prototype.occurances = function occurances(search) {
            var count, index;
            count = 0;
            index = this.indexOf(search);
            while (index !== -1) {
                count++;
                index = this.indexOf(search, index + 1);
            }
            return count;
        };
        StringExtensions.prototype.padLeft = function padLeft(paddedLength, padChar) {
            var ___al = arguments.length;
            var ___padChar$1k = (___al > 1 ? padChar : (' '));
            return ___padChar$1k.repeat(Math.max(0, paddedLength - this.length)) + this.valueOf();
        };
        StringExtensions.prototype.padRight = function padRight(paddedLength, padChar) {
            var ___al = arguments.length;
            var ___padChar$1m = (___al > 1 ? padChar : (' '));
            return this.valueOf() + ___padChar$1m.repeat(Math.max(0, paddedLength - this.length));
        };
        StringExtensions.prototype.jsify = function jsify(quoteType) {
            if (quoteType === "'") {
                return this.replace(/([\\'])/g, "\\$1").replace(/\r?\n/g, '\\n\\\n').replace(/\0/g, "\\0");
            } else if (quoteType === '"') {
                return this.replace(/([\\"])/g, "\\$1").replace(/\r?\n/g, '\\n\\\n').replace(/\0/g, "\\0");
            } else {
                return this.replace(/([\\"'])/g, "\\$1").replace(/\r?\n/g, '\\n\\\n').replace(/\0/g, "\\0");
            }
        };
        StringExtensions.prototype.capitalize = function capitalize() {
            return this.charAt(0).toUpperCase() + this.slice(1);
        };
        StringExtensions.prototype.decapitalize = function decapitalize() {
            return this.charAt(0).toLowerCase() + this.slice(1);
        };
        return StringExtensions;
    })();
    random = function random(length, chars) {
        var ___al = arguments.length;
        var numChars, result;
        var ___length$1r = (___al > 0 ? length : (16));
        var ___chars$1s = (___al > 1 ? chars : ('0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'));
        numChars = ___chars$1s.length;
        result = '';
        var i, rnum;
        for (i = 0; i < ___length$1r;i++) {
            rnum = Math.floor(Math.random() * numChars);
            result += ___chars$1s.substr(rnum, 1);
        }
        return result;
    };
    repeat = function repeat(count, string) {
        var ___al = arguments.length;
        var ___string$1u = (___al > 1 ? string : (' '));
        return StringExtensions.prototype.repeat.call(___string$1u, count);
    };
    module.exports = StringExtensions;
    module.exports.extend = extend;
    module.exports.random = random;
    module.exports.repeat = repeat;
});
module('../../astdlib/astd/prototype.adria', function(module, resource) {
    var extend, prototype;
    extend = function extend() {
        var protoName;
        for (protoName in prototype) {
            if (protoName !== 'extend') {
                prototype[protoName].extend();
            }
        }
    };
    prototype = {
        'Array': require('../../astdlib/astd/prototype/array.adria'),
        'Date': require('../../astdlib/astd/prototype/date.adria'),
        'Function': require('../../astdlib/astd/prototype/function.adria'),
        'Math': require('../../astdlib/astd/prototype/math.adria'),
        'Number': require('../../astdlib/astd/prototype/number.adria'),
        'Object': require('../../astdlib/astd/prototype/object.adria'),
        'RegExp': require('../../astdlib/astd/prototype/regexp.adria'),
        'String': require('../../astdlib/astd/prototype/string.adria')
    };
    module.exports = prototype;
    module.exports.extend = extend;
});
module('test/test.adria', function(module, resource) {
    var Test;
    Test = (function() {
        function Test(host) {
            assert.type('object', false, host, 'argument 1 (host)');
            this.host = host;
        }
        Test.prototype.host = null;
        Test.prototype.start = function start() {
            this.host.innerHTML = 'Testing 123';
        };
        return Test;
    })();
    module.exports = Test;
});
module('test/main.adria', function(module, resource) {
    var Test;
    require('../../astdlib/astd/prototype.adria').extend();
    Test = require('test/test.adria');
    application(Test, document.getElementById('ContentContainer'));
    application.start();
});
require('test/main.adria');
})(self);
//# sourceMappingURL=test.map